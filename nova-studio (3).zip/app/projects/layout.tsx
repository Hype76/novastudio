import DashboardLayout from "@/app/dashboard/layout";

// Re-use the dashboard layout (sidebar + navbar) for projects
export default DashboardLayout;
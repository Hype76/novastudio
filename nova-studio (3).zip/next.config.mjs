/** @type {import('next').NextConfig} */
const nextConfig = {
    // Optimization for standalone builds if needed
    // output: "standalone",
};

export default nextConfig;